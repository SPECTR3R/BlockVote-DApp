document.write("<script type='text/javascript' charset='utf-8' src='./resources/jim/javascript/jim-min.js'></script>");
document.write("<script type='text/javascript' charset='utf-8' src='./resources/scenarios/function-jim-links-1636087288310.js'></script>");
document.write("<script type='text/javascript' charset='utf-8' src='./resources/prototype-1636087288310.js'></script>");