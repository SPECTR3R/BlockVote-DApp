var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1636087288310.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1636087288310-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-a66d5274-125a-4b5a-94f0-79b1e9e9a649" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Validavotounico" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/a66d5274-125a-4b5a-94f0-79b1e9e9a649-1636087288310.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/a66d5274-125a-4b5a-94f0-79b1e9e9a649-1636087288310-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/a66d5274-125a-4b5a-94f0-79b1e9e9a649-1636087288310-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Paragraph" class="pie richtext autofit firer ie-background commentable non-processed" customid="Ingresa Clave de Afiliado"   datasizewidth="151.9px" datasizeheight="15.0px" dataX="323.0" dataY="307.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_0">Ingresa Clave de Afiliado:</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_2" class="pie image firer ie-background commentable non-processed" customid="Image 2"   datasizewidth="137.0px" datasizeheight="48.0px" dataX="62.0" dataY="66.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/dd43395f-681e-4d75-9ad8-49711731f160.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Input" class="pie text firer commentable non-processed" customid="Input"  datasizewidth="253.0px" datasizeheight="29.0px" dataX="500.0" dataY="300.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Button" class="pie button multiline manualfit firer click commentable non-processed" customid="Valida Voto Unico"  title="call validaVotounico(clave de afiliado)" datasizewidth="165.0px" datasizeheight="32.0px" dataX="530.0" dataY="400.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_0">Valida Voto Unico</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;