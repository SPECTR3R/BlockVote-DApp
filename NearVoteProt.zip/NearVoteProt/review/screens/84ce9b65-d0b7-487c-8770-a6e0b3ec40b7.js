var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1636087288310.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1636087288310-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-84ce9b65-d0b7-487c-8770-a6e0b3ec40b7" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Salir" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/84ce9b65-d0b7-487c-8770-a6e0b3ec40b7-1636087288310.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/84ce9b65-d0b7-487c-8770-a6e0b3ec40b7-1636087288310-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/84ce9b65-d0b7-487c-8770-a6e0b3ec40b7-1636087288310-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Button" class="pie button multiline manualfit firer click commentable non-processed" customid="Desconectarte"   datasizewidth="92.0px" datasizeheight="32.0px" dataX="594.0" dataY="505.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_0">Desconectarte</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_7" class="pie richtext manualfit firer commentable non-processed" customid="GRACIAS por tu participac"   datasizewidth="558.0px" datasizeheight="42.0px" dataX="374.0" dataY="167.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_7_0">GRACIAS por tu participaci&oacute;n, &nbsp;la votaci&oacute;n esta como sigue:</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_2" class="pie image firer ie-background commentable non-processed" customid="Image 2"   datasizewidth="137.0px" datasizeheight="48.0px" dataX="77.0" dataY="54.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/dd43395f-681e-4d75-9ad8-49711731f160.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Rectangle" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle"   datasizewidth="140.5px" datasizeheight="102.0px" datasizewidthpx="140.5" datasizeheightpx="102.0" dataX="235.0" dataY="268.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_0">Planilla Blanca</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_1" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle"   datasizewidth="140.5px" datasizeheight="102.0px" datasizewidthpx="140.5" datasizeheightpx="102.0" dataX="439.7" dataY="268.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0">Planilla Roja</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_2" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle"   datasizewidth="140.5px" datasizeheight="102.0px" datasizewidthpx="140.5" datasizeheightpx="102.0" dataX="644.3" dataY="268.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_2_0">Planilla Amarilla</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_3" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle"   datasizewidth="140.5px" datasizeheight="102.0px" datasizewidthpx="140.5" datasizeheightpx="102.0" dataX="849.0" dataY="268.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_3_0">Planilla Verde</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input" class="pie text firer commentable non-processed" customid="Input" title="call &nbsp;getVotescpb()" datasizewidth="91.3px" datasizeheight="29.0px" dataX="254.0" dataY="412.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Votos:51"/></div></div>  </div></div></div>\
      <div id="s-Input_1" class="pie text firer commentable non-processed" customid="Input" title="call &nbsp;getVotescpr()" datasizewidth="91.3px" datasizeheight="29.0px" dataX="464.3" dataY="412.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Votos: 45"/></div></div>  </div></div></div>\
      <div id="s-Input_2" class="pie text firer commentable non-processed" customid="Input" title="call &nbsp;getVotescpa()" datasizewidth="91.3px" datasizeheight="29.0px" dataX="669.0" dataY="412.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Votos: 22"/></div></div>  </div></div></div>\
      <div id="s-Input_3" class="pie text firer click commentable non-processed" customid="Input" title="call &nbsp;getVotescpv()" datasizewidth="91.3px" datasizeheight="29.0px" dataX="873.6" dataY="412.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Votos: 10"/></div></div>  </div></div></div>\
      <div id="s-Input_4" class="pie text firer commentable non-processed" customid="Input" title="call &nbsp;getVotes()" datasizewidth="217.3px" datasizeheight="29.0px" dataX="531.0" dataY="214.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Total de Votos Emitidos: &nbsp;128"/></div></div>  </div></div></div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;