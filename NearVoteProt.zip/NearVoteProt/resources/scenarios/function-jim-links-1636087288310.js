(function(window, undefined) {

  var jimLinks = {
    "d2f7cc3e-1f2f-4e22-9235-b0829444e9b1" : {
      "Button" : [
        "a26ad6fe-981b-4dba-97c5-6260b0d8beaa"
      ],
      "Button_1" : [
        "a66d5274-125a-4b5a-94f0-79b1e9e9a649"
      ]
    },
    "a66d5274-125a-4b5a-94f0-79b1e9e9a649" : {
      "Button" : [
        "39c0251d-95ad-409a-96f2-b24a6784777c",
        "116600d0-4054-42b4-a597-fe40ac7dfce5"
      ]
    },
    "84ce9b65-d0b7-487c-8770-a6e0b3ec40b7" : {
      "Button" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Input_3" : [
        "5e4a537d-2fdb-4876-8997-a477d7469985"
      ]
    },
    "5e4a537d-2fdb-4876-8997-a477d7469985" : {
      "Button" : [
        "84ce9b65-d0b7-487c-8770-a6e0b3ec40b7"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Button" : [
        "a26ad6fe-981b-4dba-97c5-6260b0d8beaa"
      ]
    },
    "a26ad6fe-981b-4dba-97c5-6260b0d8beaa" : {
      "Button" : [
        "d2f7cc3e-1f2f-4e22-9235-b0829444e9b1"
      ],
      "Button_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "116600d0-4054-42b4-a597-fe40ac7dfce5" : {
      "Button" : [
        "5e4a537d-2fdb-4876-8997-a477d7469985"
      ],
      "Button_1" : [
        "5e4a537d-2fdb-4876-8997-a477d7469985"
      ],
      "Button_2" : [
        "5e4a537d-2fdb-4876-8997-a477d7469985"
      ],
      "Button_3" : [
        "5e4a537d-2fdb-4876-8997-a477d7469985"
      ]
    },
    "39c0251d-95ad-409a-96f2-b24a6784777c" : {
      "Button" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);