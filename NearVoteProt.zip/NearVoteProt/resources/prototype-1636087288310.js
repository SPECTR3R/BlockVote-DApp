(function(window, undefined) {
  var dictionary = {
  };

  window.jimDevelopers.lookUpSlice = function(name) {
    var imageName;
    if(dictionary.hasOwnProperty(name)) { /* search by name */
      imageName = dictionary[name];
    }
    return imageName;
  };
})(window);	window.widgets = {
		descriptionMap : widgetDescriptionMap = {},
		rootWidgetMap : widgetRootMap = {}
	};

	widgets.descriptionMap[["s-Button", "d2f7cc3e-1f2f-4e22-9235-b0829444e9b1"]] = ""; 

			widgets.rootWidgetMap[["s-Button", "d2f7cc3e-1f2f-4e22-9235-b0829444e9b1"]] = ["Button", "s-Button"]; 

	widgets.descriptionMap[["s-Button_1", "d2f7cc3e-1f2f-4e22-9235-b0829444e9b1"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "d2f7cc3e-1f2f-4e22-9235-b0829444e9b1"]] = ["Button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Paragraph", "a66d5274-125a-4b5a-94f0-79b1e9e9a649"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph", "a66d5274-125a-4b5a-94f0-79b1e9e9a649"]] = ["Text", "s-Paragraph"]; 

	widgets.descriptionMap[["s-Input", "a66d5274-125a-4b5a-94f0-79b1e9e9a649"]] = ""; 

			widgets.rootWidgetMap[["s-Input", "a66d5274-125a-4b5a-94f0-79b1e9e9a649"]] = ["Input Text Field", "s-Input"]; 

	widgets.descriptionMap[["s-Button", "a66d5274-125a-4b5a-94f0-79b1e9e9a649"]] = ""; 

			widgets.rootWidgetMap[["s-Button", "a66d5274-125a-4b5a-94f0-79b1e9e9a649"]] = ["Button", "s-Button"]; 

	widgets.descriptionMap[["s-Button", "84ce9b65-d0b7-487c-8770-a6e0b3ec40b7"]] = ""; 

			widgets.rootWidgetMap[["s-Button", "84ce9b65-d0b7-487c-8770-a6e0b3ec40b7"]] = ["Button", "s-Button"]; 

	widgets.descriptionMap[["s-Paragraph_7", "84ce9b65-d0b7-487c-8770-a6e0b3ec40b7"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "84ce9b65-d0b7-487c-8770-a6e0b3ec40b7"]] = ["Title", "s-Paragraph_7"]; 

	widgets.descriptionMap[["s-Rectangle", "84ce9b65-d0b7-487c-8770-a6e0b3ec40b7"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle", "84ce9b65-d0b7-487c-8770-a6e0b3ec40b7"]] = ["Rectangle", "s-Rectangle"]; 

	widgets.descriptionMap[["s-Rectangle_1", "84ce9b65-d0b7-487c-8770-a6e0b3ec40b7"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "84ce9b65-d0b7-487c-8770-a6e0b3ec40b7"]] = ["Rectangle", "s-Rectangle_1"]; 

	widgets.descriptionMap[["s-Rectangle_2", "84ce9b65-d0b7-487c-8770-a6e0b3ec40b7"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "84ce9b65-d0b7-487c-8770-a6e0b3ec40b7"]] = ["Rectangle", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Rectangle_3", "84ce9b65-d0b7-487c-8770-a6e0b3ec40b7"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "84ce9b65-d0b7-487c-8770-a6e0b3ec40b7"]] = ["Rectangle", "s-Rectangle_3"]; 

	widgets.descriptionMap[["s-Input", "84ce9b65-d0b7-487c-8770-a6e0b3ec40b7"]] = ""; 

			widgets.rootWidgetMap[["s-Input", "84ce9b65-d0b7-487c-8770-a6e0b3ec40b7"]] = ["Input Text Field", "s-Input"]; 

	widgets.descriptionMap[["s-Input_1", "84ce9b65-d0b7-487c-8770-a6e0b3ec40b7"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "84ce9b65-d0b7-487c-8770-a6e0b3ec40b7"]] = ["Input Text Field", "s-Input_1"]; 

	widgets.descriptionMap[["s-Input_2", "84ce9b65-d0b7-487c-8770-a6e0b3ec40b7"]] = ""; 

			widgets.rootWidgetMap[["s-Input_2", "84ce9b65-d0b7-487c-8770-a6e0b3ec40b7"]] = ["Input Text Field", "s-Input_2"]; 

	widgets.descriptionMap[["s-Input_3", "84ce9b65-d0b7-487c-8770-a6e0b3ec40b7"]] = ""; 

			widgets.rootWidgetMap[["s-Input_3", "84ce9b65-d0b7-487c-8770-a6e0b3ec40b7"]] = ["Input Text Field", "s-Input_3"]; 

	widgets.descriptionMap[["s-Input_4", "84ce9b65-d0b7-487c-8770-a6e0b3ec40b7"]] = ""; 

			widgets.rootWidgetMap[["s-Input_4", "84ce9b65-d0b7-487c-8770-a6e0b3ec40b7"]] = ["Input Text Field", "s-Input_4"]; 

	widgets.descriptionMap[["s-Button", "5e4a537d-2fdb-4876-8997-a477d7469985"]] = ""; 

			widgets.rootWidgetMap[["s-Button", "5e4a537d-2fdb-4876-8997-a477d7469985"]] = ["Button", "s-Button"]; 

	widgets.descriptionMap[["s-Paragraph_7", "5e4a537d-2fdb-4876-8997-a477d7469985"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "5e4a537d-2fdb-4876-8997-a477d7469985"]] = ["Title", "s-Paragraph_7"]; 

	widgets.descriptionMap[["s-Paragraph", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Text", "s-Paragraph"]; 

	widgets.descriptionMap[["s-Paragraph_7", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Title", "s-Paragraph_7"]; 

	widgets.descriptionMap[["s-Button", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Button", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Button", "s-Button"]; 

	widgets.descriptionMap[["s-Paragraph_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Title", "s-Paragraph_8"]; 

	widgets.descriptionMap[["s-Button", "a26ad6fe-981b-4dba-97c5-6260b0d8beaa"]] = ""; 

			widgets.rootWidgetMap[["s-Button", "a26ad6fe-981b-4dba-97c5-6260b0d8beaa"]] = ["Button", "s-Button"]; 

	widgets.descriptionMap[["s-Button_1", "a26ad6fe-981b-4dba-97c5-6260b0d8beaa"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "a26ad6fe-981b-4dba-97c5-6260b0d8beaa"]] = ["Button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Button", "116600d0-4054-42b4-a597-fe40ac7dfce5"]] = ""; 

			widgets.rootWidgetMap[["s-Button", "116600d0-4054-42b4-a597-fe40ac7dfce5"]] = ["Button", "s-Button"]; 

	widgets.descriptionMap[["s-Button_1", "116600d0-4054-42b4-a597-fe40ac7dfce5"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "116600d0-4054-42b4-a597-fe40ac7dfce5"]] = ["Button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Button_2", "116600d0-4054-42b4-a597-fe40ac7dfce5"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "116600d0-4054-42b4-a597-fe40ac7dfce5"]] = ["Button", "s-Button_2"]; 

	widgets.descriptionMap[["s-Button_3", "116600d0-4054-42b4-a597-fe40ac7dfce5"]] = ""; 

			widgets.rootWidgetMap[["s-Button_3", "116600d0-4054-42b4-a597-fe40ac7dfce5"]] = ["Button", "s-Button_3"]; 

	widgets.descriptionMap[["s-Rectangle", "116600d0-4054-42b4-a597-fe40ac7dfce5"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle", "116600d0-4054-42b4-a597-fe40ac7dfce5"]] = ["Rectangle", "s-Rectangle"]; 

	widgets.descriptionMap[["s-Rectangle_1", "116600d0-4054-42b4-a597-fe40ac7dfce5"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "116600d0-4054-42b4-a597-fe40ac7dfce5"]] = ["Rectangle", "s-Rectangle_1"]; 

	widgets.descriptionMap[["s-Rectangle_2", "116600d0-4054-42b4-a597-fe40ac7dfce5"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "116600d0-4054-42b4-a597-fe40ac7dfce5"]] = ["Rectangle", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Rectangle_3", "116600d0-4054-42b4-a597-fe40ac7dfce5"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "116600d0-4054-42b4-a597-fe40ac7dfce5"]] = ["Rectangle", "s-Rectangle_3"]; 

	widgets.descriptionMap[["s-Button", "39c0251d-95ad-409a-96f2-b24a6784777c"]] = ""; 

			widgets.rootWidgetMap[["s-Button", "39c0251d-95ad-409a-96f2-b24a6784777c"]] = ["Button", "s-Button"]; 

	widgets.descriptionMap[["s-Paragraph_7", "39c0251d-95ad-409a-96f2-b24a6784777c"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "39c0251d-95ad-409a-96f2-b24a6784777c"]] = ["Title", "s-Paragraph_7"]; 

	(function(window, undefined) {
  var dictionary = {
    "d2f7cc3e-1f2f-4e22-9235-b0829444e9b1": "PermiteConexion",
    "a66d5274-125a-4b5a-94f0-79b1e9e9a649": "Validavotounico",
    "84ce9b65-d0b7-487c-8770-a6e0b3ec40b7": "Salir",
    "5e4a537d-2fdb-4876-8997-a477d7469985": "EmiteVoto",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "NearVote",
    "a26ad6fe-981b-4dba-97c5-6260b0d8beaa": "SolicitaConexion",
    "116600d0-4054-42b4-a597-fe40ac7dfce5": "MuestraCandidatos",
    "39c0251d-95ad-409a-96f2-b24a6784777c": "Ya Voto",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);jQuery("#simulation")
  .on("click", ".s-d2f7cc3e-1f2f-4e22-9235-b0829444e9b1 .click", function(event, data) {
    var jEvent, jFirer, cases;
    if(jimUtil.isAlternateModeActive()) return;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Button")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/a26ad6fe-981b-4dba-97c5-6260b0d8beaa",
                    "transition": {
                      "type": "slideandfade",
                      "duration": 500
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Button_1")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/a66d5274-125a-4b5a-94f0-79b1e9e9a649",
                    "transition": {
                      "type": "slideandfade",
                      "duration": 500
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  });function initData() {
  jimData.variables["Valido"] = "1234";
  jimData.variables["INVALIDO"] = "";
  jimData.isInitialized = true;
}jQuery("#simulation")
  .on("click", ".s-a66d5274-125a-4b5a-94f0-79b1e9e9a649 .click", function(event, data) {
    var jEvent, jFirer, cases;
    if(jimUtil.isAlternateModeActive()) return;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Button")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimEquals",
                "parameter": [ {
                  "datatype": "property",
                  "target": "#s-Input",
                  "property": "jimGetValue"
                },"99999" ]
              },
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/39c0251d-95ad-409a-96f2-b24a6784777c",
                    "transition": {
                      "type": "slideandfade",
                      "duration": 700
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            },
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/116600d0-4054-42b4-a597-fe40ac7dfce5",
                    "transition": {
                      "type": "slideandfade",
                      "duration": 700
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  });jQuery("#simulation")
  .on("click", ".s-84ce9b65-d0b7-487c-8770-a6e0b3ec40b7 .click", function(event, data) {
    var jEvent, jFirer, cases;
    if(jimUtil.isAlternateModeActive()) return;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Button")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/d12245cc-1680-458d-89dd-4f0d7fb22724",
                    "transition": {
                      "type": "slideandfade",
                      "duration": 500
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Input_3")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/5e4a537d-2fdb-4876-8997-a477d7469985"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  });jQuery("#simulation")
  .on("click", ".s-5e4a537d-2fdb-4876-8997-a477d7469985 .click", function(event, data) {
    var jEvent, jFirer, cases;
    if(jimUtil.isAlternateModeActive()) return;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Button")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/84ce9b65-d0b7-487c-8770-a6e0b3ec40b7",
                    "transition": {
                      "type": "slideandfade",
                      "duration": 500
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  });jQuery("#simulation")
  .on("click", ".s-d12245cc-1680-458d-89dd-4f0d7fb22724 .click", function(event, data) {
    var jEvent, jFirer, cases;
    if(jimUtil.isAlternateModeActive()) return;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Button")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/a26ad6fe-981b-4dba-97c5-6260b0d8beaa",
                    "transition": {
                      "type": "slideandfade",
                      "duration": 500
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  });jQuery("#simulation")
  .on("click", ".s-a26ad6fe-981b-4dba-97c5-6260b0d8beaa .click", function(event, data) {
    var jEvent, jFirer, cases;
    if(jimUtil.isAlternateModeActive()) return;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Button")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/d2f7cc3e-1f2f-4e22-9235-b0829444e9b1",
                    "transition": {
                      "type": "slideandfade",
                      "duration": 500
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Button_1")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/d12245cc-1680-458d-89dd-4f0d7fb22724"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  });jQuery("#simulation")
  .on("click", ".s-116600d0-4054-42b4-a597-fe40ac7dfce5 .click", function(event, data) {
    var jEvent, jFirer, cases;
    if(jimUtil.isAlternateModeActive()) return;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Button")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/5e4a537d-2fdb-4876-8997-a477d7469985",
                    "transition": {
                      "type": "slideandfade",
                      "duration": 500
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Button_1")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/5e4a537d-2fdb-4876-8997-a477d7469985",
                    "transition": {
                      "type": "slideandfade",
                      "duration": 500
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Button_2")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/5e4a537d-2fdb-4876-8997-a477d7469985"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Button_3")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/5e4a537d-2fdb-4876-8997-a477d7469985",
                    "transition": {
                      "type": "slideandfade",
                      "duration": 500
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  });jQuery("#simulation")
  .on("click", ".s-39c0251d-95ad-409a-96f2-b24a6784777c .click", function(event, data) {
    var jEvent, jFirer, cases;
    if(jimUtil.isAlternateModeActive()) return;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Button")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/d12245cc-1680-458d-89dd-4f0d7fb22724",
                    "transition": {
                      "type": "slideandfade",
                      "duration": 500
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  });